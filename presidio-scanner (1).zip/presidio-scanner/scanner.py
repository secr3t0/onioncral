#!/usr/bin/env python3
"""
Scanner de Dados Sensíveis (PII) baseado em Microsoft Presidio.

Varre recursivamente um diretório em busca de CPF, CNPJ, e-mail, telefone
brasileiro, cartão de crédito, IP e URL em arquivos PDF, DOCX, XLSX, XLS,
CSV, TXT, JSON e LOG — gerando relatórios em CSV.

Roda 100% localmente: nenhum arquivo ou dado é enviado para serviços
externos, APIs, nuvem ou provedores de IA.

Uso:
    python3 scanner.py /caminho/para/analisar
    python3 scanner.py /caminho --ocr
    python3 scanner.py /caminho --detailed
    python3 scanner.py /caminho --workers 8
    python3 scanner.py /caminho --ocr --detailed --workers 4
    python3 scanner.py --help
"""

import argparse
import logging
import sys
import time
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

from tqdm import tqdm

from scanner.extractors import EXTENSOES_SUPORTADAS
from scanner.reporters import AgregadorResultados, escrever_erros
from scanner.utils import (
    classificar_documento_por_nome,
    configurar_logging,
    inicializar_worker,
    listar_arquivos,
    processar_arquivo,
)

NOME_RESULTADO = "resultado.csv"
NOME_RESULTADO_DETALHADO = "resultado_detalhado.csv"
NOME_ERROS = "erros.csv"
NOME_LOG = "scanner.log"


def montar_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="scanner.py",
        description=(
            "Scanner de dados sensíveis (PII) com Microsoft Presidio: varre "
            "recursivamente um diretório e identifica CPF, CNPJ, e-mail, "
            "telefone, cartão de crédito, IP e URL em PDF, DOCX, XLSX, XLS, "
            "CSV, TXT, JSON e LOG. Execução 100% local."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Exemplos:\n"
            "  python3 scanner.py /dados\n"
            "  python3 scanner.py /dados --ocr\n"
            "  python3 scanner.py /dados --detailed\n"
            "  python3 scanner.py /dados --workers 8\n"
            "  python3 scanner.py /dados --ocr --detailed --workers 4\n"
            "  python3 scanner.py /dados --exclude \".iso,.zip,.tar,.gz\" "
            "--exclude-dir \"/proc,/sys,/dev\"\n"
        ),
    )
    parser.add_argument("caminho", help="Diretório raiz a ser varrido recursivamente.")
    parser.add_argument(
        "--ocr", action="store_true",
        help="Habilita OCR (Tesseract) para páginas de PDF sem texto extraível. "
             "Desabilitado por padrão pois é mais lento.",
    )
    parser.add_argument(
        "--detailed", action="store_true",
        help="Gera também o resultado_detalhado.csv com valores mascarados e score.",
    )
    parser.add_argument(
        "--workers", type=int, default=4,
        help="Número de processos paralelos (padrão: 4).",
    )
    parser.add_argument(
        "--exclude", default="",
        help='Extensões a ignorar, separadas por vírgula. Ex: ".iso,.zip,.tar,.gz"',
    )
    parser.add_argument(
        "--exclude-dir", default="",
        help='Diretórios a ignorar, separados por vírgula. Ex: "/proc,/sys,/dev"',
    )
    parser.add_argument(
        "--output-dir", default=".",
        help="Diretório onde os relatórios (resultado.csv, erros.csv, scanner.log) serão gravados. Padrão: diretório atual.",
    )
    return parser


def main():
    parser = montar_parser()
    args = parser.parse_args()

    caminho_raiz = Path(args.caminho)
    if not caminho_raiz.exists():
        print(f"Erro: o caminho '{caminho_raiz}' não existe.", file=sys.stderr)
        sys.exit(1)
    if not caminho_raiz.is_dir():
        print(f"Erro: o caminho '{caminho_raiz}' não é um diretório.", file=sys.stderr)
        sys.exit(1)

    diretorio_saida = Path(args.output_dir)
    diretorio_saida.mkdir(parents=True, exist_ok=True)

    logger = configurar_logging(diretorio_saida / NOME_LOG)
    logger.info("Iniciando varredura em: %s", caminho_raiz)
    logger.info("Opções: ocr=%s detailed=%s workers=%s", args.ocr, args.detailed, args.workers)

    inicio = time.time()

    # 1) Levantamento de todos os arquivos, separando suportados de não suportados
    tarefas = []
    nao_suportados = 0
    for caminho_arquivo, extensao in listar_arquivos(str(caminho_raiz), args.exclude, args.exclude_dir):
        if extensao in EXTENSOES_SUPORTADAS:
            tarefas.append((str(caminho_arquivo), extensao))
        else:
            nao_suportados += 1
            logger.info("Arquivo com extensão não suportada, ignorado: %s", caminho_arquivo)

    total_encontrados = len(tarefas) + nao_suportados
    print(f"Total de arquivos encontrados: {total_encontrados}")
    print(f"Arquivos suportados para análise: {len(tarefas)}")
    print(f"Arquivos ignorados (extensão não suportada): {nao_suportados}")

    if not tarefas:
        print("Nenhum arquivo suportado encontrado. Encerrando.")
        return

    # 2) Processamento paralelo
    agregador = AgregadorResultados(detalhado=args.detailed)
    erros = []
    arquivos_com_erro = 0
    arquivos_analisados = 0

    with ProcessPoolExecutor(
        max_workers=args.workers,
        initializer=inicializar_worker,
        initargs=(args.ocr,),
    ) as executor:
        futuros = {
            executor.submit(processar_arquivo, caminho, ext): (caminho, ext)
            for caminho, ext in tarefas
        }

        barra_progresso = tqdm(as_completed(futuros), total=len(futuros), desc="Analisando arquivos", unit="arq")
        for futuro in barra_progresso:
            caminho, ext = futuros[futuro]
            tipo_arquivo = EXTENSOES_SUPORTADAS[ext][0]
            try:
                resultado = futuro.result()
            except Exception as e:  # noqa: BLE001 - falha inesperada no próprio worker
                arquivos_com_erro += 1
                tipo_documento = classificar_documento_por_nome(Path(caminho))
                erros.append((caminho, tipo_arquivo, tipo_documento, f"Falha no processo worker: {e}"))
                logger.error("Falha no worker ao processar %s: %s", caminho, e)
                continue

            if resultado["erro"]:
                arquivos_com_erro += 1
                erros.append((resultado["arquivo"], resultado["tipo_arquivo"], resultado["tipo_documento"], resultado["erro"]))
                logger.warning("Erro ao processar %s: %s", resultado["arquivo"], resultado["erro"])
            else:
                arquivos_analisados += 1
                for ocorrencia in resultado["ocorrencias"]:
                    agregador.adicionar_ocorrencia(
                        arquivo=resultado["arquivo"],
                        tipo_arquivo=resultado["tipo_arquivo"],
                        tipo_documento=resultado["tipo_documento"],
                        localizacao=ocorrencia["localizacao"],
                        tipo_dado=ocorrencia["tipo_dado"],
                        valor=ocorrencia["valor"],
                        score=ocorrencia["score"],
                    )

    # 3) Geração dos relatórios
    caminho_resultado = diretorio_saida / NOME_RESULTADO
    agregador.escrever_resultado(caminho_resultado)
    print(f"\nRelatório gerado: {caminho_resultado}")

    if args.detailed:
        caminho_detalhado = diretorio_saida / NOME_RESULTADO_DETALHADO
        agregador.escrever_detalhado(caminho_detalhado)
        print(f"Relatório detalhado gerado: {caminho_detalhado}")

    caminho_erros = diretorio_saida / NOME_ERROS
    escrever_erros(caminho_erros, erros)
    print(f"Log de erros gerado: {caminho_erros}")

    # 4) Resumo final
    duracao = time.time() - inicio
    print("\n===== Resumo da varredura =====")
    print(f"Total de arquivos encontrados : {total_encontrados}")
    print(f"Arquivos analisados           : {arquivos_analisados}")
    print(f"Arquivos com erro             : {arquivos_com_erro}")
    print(f"Arquivos ignorados (extensão) : {nao_suportados}")
    print("Ocorrências por tipo de dado:")
    for tipo_dado, quantidade in sorted(agregador.total_ocorrencias_por_tipo.items()):
        print(f"  {tipo_dado:<20} {quantidade}")
    print(f"Tempo total                   : {duracao:.1f}s")

    logger.info("Varredura concluída em %.1fs. Analisados=%d Erros=%d", duracao, arquivos_analisados, arquivos_com_erro)


if __name__ == "__main__":
    main()
