# Presidio Scanner — Scanner de Dados Sensíveis (PII)

Ferramenta de linha de comando para varrer recursivamente diretórios em
sistemas Linux e identificar dados sensíveis (PII) em arquivos PDF, DOCX,
XLSX, XLS, CSV, TXT, JSON e LOG, usando o **Microsoft Presidio** como motor
de detecção, com recognizers customizados para **CPF** e **CNPJ**
(incluindo validação de dígitos verificadores) e telefone brasileiro.

**Execução 100% local.** Nenhum arquivo, texto ou dado é enviado para
serviços externos, APIs, provedores de IA ou nuvem — tudo roda no
processo local usando spaCy + Presidio.

## O que é detectado

| Tipo de dado       | Entidade no relatório | Validação                              |
|--------------------|------------------------|-----------------------------------------|
| CPF                | `CPF`                  | Dígitos verificadores (algoritmo oficial) |
| CNPJ               | `CNPJ`                 | Dígitos verificadores (algoritmo oficial) |
| RG                 | `RG`                   | Estrutural (regex) + reforço por contexto (não há checksum nacional único, pois cada estado emite o RG de forma diferente) |
| E-mail             | `EMAIL_ADDRESS`        | Recognizer nativo do Presidio            |
| Telefone BR        | `PHONE_NUMBER_BR`      | Regex + reforço por contexto             |
| Cartão de crédito  | `CREDIT_CARD`          | Algoritmo de Luhn (nativo do Presidio)   |
| Endereço IP        | `IP_ADDRESS`           | Recognizer nativo do Presidio            |
| URL                | `URL`                  | Recognizer nativo do Presidio            |

Além disso, cada arquivo é classificado em um **tipo de documento**, com base
em palavras-chave encontradas no **nome do arquivo** (não no conteúdo):

| Categoria         | Palavras-chave reconhecidas no nome do arquivo |
|-------------------|--------------------------------------------------|
| Diploma           | `diploma`                                        |
| Ficha Cadastral   | `ficha cadastral`, `ficha_cadastral`, `fichacadastral`, `ficha` |
| Laudo             | `laudo`                                          |
| Prontuario        | `prontuario`                                     |
| Contrato          | `contrato`                                       |

Um arquivo que não corresponder a nenhuma categoria recebe `Não classificado`.
Se o nome contiver palavras de mais de uma categoria (ex:
`laudo_e_prontuario_joao.pdf`), todas são listadas, separadas por `; `
(ex: `Laudo; Prontuario`).

## Instalação (Ubuntu / Debian)

```bash
# 1. Dependências de sistema
sudo apt update
sudo apt install -y python3-venv python3-pip

# Somente se for usar a opção --ocr:
sudo apt install -y tesseract-ocr tesseract-ocr-por

# 2. Ambiente virtual (você mencionou já ter um criado — adapte se necessário)
python3 -m venv venv
source venv/bin/activate

# 3. Dependências Python
pip install -r requirements.txt

# 4. Modelo de português do spaCy (obrigatório)
python -m spacy download pt_core_news_sm
```

> Se for usar `--ocr`, garanta que o binário `tesseract` está no PATH:
> `tesseract --version`. O pacote `tesseract-ocr-por` fornece o modelo de
> português usado pelo OCR (`lang="por"`).

## Uso

```bash
# Varredura básica (gera resultado.csv, erros.csv, scanner.log)
python3 scanner.py /datadisk/evidence_case/evidence/

# Habilitando OCR para PDFs sem texto extraível (mais lento)
python3 scanner.py /dados --ocr

# Gerando também o relatório detalhado (valores mascarados + score)
python3 scanner.py /dados --detailed

# Ajustando o número de processos paralelos
python3 scanner.py /dados --workers 8

# Combinando todas as opções
python3 scanner.py /dados --ocr --detailed --workers 4

# Excluindo extensões e diretórios específicos
python3 scanner.py /dados --exclude ".iso,.zip,.tar,.gz" --exclude-dir "/proc,/sys,/dev"

# Definindo onde os relatórios serão gravados (padrão: diretório atual)
python3 scanner.py /dados --output-dir /tmp/relatorios

# Ajuda completa
python3 scanner.py --help
```

### Exemplo com o caminho mencionado no seu ambiente

```bash
python3 scanner.py "/datadisk/evidence_case/evidence/e4d2e6cbb9dfa25ebc7b4caf0266bb60/MCDCSRVFS01/127.0.0.1/D_/Fejal/Maceio/" --detailed --workers 4
```

## Arquivos gerados

- **`resultado.csv`** (sempre gerado) — contagens agregadas, **sem** valores sensíveis:
  ```text
  arquivo,tipo_arquivo,tipo_documento,localizacao,tipo_dado,quantidade
  /dados/RH/funcionarios.xlsx,XLSX,Não classificado,Planilha Funcionarios,CPF,847
  /dados/contratos/contrato.pdf,PDF,Contrato,Pagina 3,CPF,2
  ```

- **`resultado_detalhado.csv`** (apenas com `--detailed`) — valores **mascarados** e score de confiança:
  ```text
  arquivo,tipo_arquivo,tipo_documento,localizacao,tipo_dado,valor_mascarado,score
  /dados/RH/funcionarios.xlsx,XLSX,Não classificado,Planilha Funcionarios,CPF,123.***.***-09,1.0
  ```
  O valor original completo **nunca** é gravado em disco, em nenhum modo.

- **`erros.csv`** — arquivos que falharam durante o processamento (corrompidos, protegidos por senha, formato inesperado, etc.), sem interromper a varredura:
  ```text
  arquivo,tipo_arquivo,tipo_documento,erro
  ```

- **`scanner.log`** — log completo da execução (INFO no arquivo, WARNING+ no console).

## Sobre a granularidade da "localização"

- **PDF**: número da página (`Pagina N`).
- **XLSX / XLS**: nome da aba (`Planilha NomeDaAba`).
- **DOCX / CSV / TXT / JSON / LOG**: unidade lógica do arquivo inteiro (`Documento` ou `Arquivo`), já que esses formatos não têm um conceito nativo de "página". Internamente, o conteúdo ainda é lido em blocos para não estourar a memória em arquivos muito grandes — apenas a contagem é agregada por arquivo.

## Notas de arquitetura e decisões de design

1. **NLP engine**: Presidio configurado com spaCy (`pt_core_news_sm`) via `NlpEngineProvider`, conforme a API pública oficial do Presidio.
2. **Telefone brasileiro**: em vez do `PhoneRecognizer` padrão do Presidio (que depende do pacote `phonenumbers` e é otimizado para outros países), foi criado um `PatternRecognizer` customizado (`PHONE_NUMBER_BR`) — evita uma dependência extra e reduz falsos positivos/negativos com formatos nacionais.
3. **CPF/CNPJ**: `PatternRecognizer` com múltiplos padrões (regex) + método `validate_result()` sobrescrito, que aplica a validação de dígitos verificadores. Matches que falham na validação recebem score mínimo e são descartados — o mesmo padrão usado pelos recognizers de documentos nacionais nativos do Presidio (ex: `KrBrnRecognizer`).
4. **OCR**: usa **PyMuPDF (`fitz`)** para renderizar páginas de PDF como imagem, em vez de `pdf2image`, pois não exige a instalação do pacote de sistema `poppler-utils` — apenas o próprio Tesseract.
5. **Paralelismo**: `ProcessPoolExecutor` com um `initializer` que constrói o `AnalyzerEngine` uma única vez por processo (o Analyzer/spaCy não é serializável entre processos do multiprocessing).
6. **Privacidade por padrão**: o valor original completo de qualquer dado sensível nunca é persistido em disco — nem no modo padrão, nem no `--detailed` (que só grava versões mascaradas).
7. **RG**: sem dígito verificador nacional único (cada estado emite de forma diferente), então a validação é estrutural (regex) reforçada por contexto — resultados fracos (score baixo) só são mantidos quando há uma palavra de contexto relevante por perto (ex: "identidade", "SSP"). Um limiar mínimo de score (`SCORE_MINIMO_PADRAO = 0.35`) é aplicado a toda a análise para reduzir ruído desse tipo de padrão fraco.
8. **Classificação de tipo de documento**: feita apenas pelo **nome do arquivo** (não pelo conteúdo), por ser rápida, previsível e não exigir OCR/parsing adicional. Arquivos sem nenhuma palavra-chave reconhecida recebem `Não classificado`.

## Estrutura do projeto

```text
presidio-scanner/
├── scanner.py              # CLI (argparse) + orquestração + paralelismo
├── requirements.txt
├── README.md
└── scanner/
    ├── __init__.py
    ├── validators.py        # Validação de CPF/CNPJ (dígitos verificadores) + Luhn
    ├── detectors.py          # AnalyzerEngine do Presidio + recognizers customizados
    ├── extractors.py         # Extração de texto por tipo de arquivo (em chunks)
    ├── reporters.py           # Agregação, mascaramento e escrita dos CSVs
    └── utils.py               # Logging, caminhada de diretórios, worker de processo
```

## Limitações conhecidas

- CNPJ alfanumérico (novo formato da Receita Federal a partir de 2026) não é validado — apenas o formato numérico tradicional de 14 dígitos.
- DOCX e CSV/TXT/JSON/LOG reportam localização no nível do arquivo, não de linha/parágrafo individual (ver seção acima).
- PDFs protegidos por senha não vazia não são processados (ficam registrados em `erros.csv`).
- O OCR depende da qualidade da digitalização; textos de baixa resolução podem gerar falsos negativos.
