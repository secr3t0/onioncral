"""
Extração de texto de diferentes tipos de arquivo, em blocos ("chunks"),
para evitar carregar arquivos inteiros na memória sempre que possível.

Cada função `extrair_*` é um gerador que produz tuplas:
    (localizacao: str, texto: str)

onde `localizacao` identifica onde, dentro do arquivo, aquele texto foi
encontrado (ex: "Pagina 3", "Planilha Vendas", "Arquivo").
"""

import csv
import json
import logging
from pathlib import Path

logger = logging.getLogger("scanner.extractors")

# Tamanho de bloco (em linhas) usado para arquivos de texto simples,
# equilibrando uso de memória e overhead de chamadas ao Presidio.
LINHAS_POR_CHUNK = 500


class ErroExtracao(Exception):
    """Erro conhecido durante a extração de um arquivo específico."""


def extrair_txt(caminho: Path):
    """TXT / LOG: lido em blocos de linhas, localizacao fixa em 'Arquivo'."""
    try:
        with open(caminho, "r", encoding="utf-8", errors="replace") as f:
            buffer = []
            for linha in f:
                buffer.append(linha)
                if len(buffer) >= LINHAS_POR_CHUNK:
                    yield "Arquivo", "".join(buffer)
                    buffer = []
            if buffer:
                yield "Arquivo", "".join(buffer)
    except OSError as e:
        raise ErroExtracao(f"Falha ao ler arquivo de texto: {e}") from e


def extrair_json(caminho: Path):
    """
    JSON: carregado e serializado de volta para string (indentado) em blocos
    por linha, já que a estrutura pode ser aninhada e não sabemos o tamanho
    a priori. Para arquivos JSON muito grandes, recomenda-se pré-processamento
    externo; aqui priorizamos correção sobre performance extrema.
    """
    try:
        with open(caminho, "r", encoding="utf-8", errors="replace") as f:
            conteudo = f.read()
    except OSError as e:
        raise ErroExtracao(f"Falha ao ler arquivo JSON: {e}") from e

    try:
        dados = json.loads(conteudo)
        texto_normalizado = json.dumps(dados, ensure_ascii=False, indent=2)
    except json.JSONDecodeError:
        # Se não for um JSON válido, ainda assim tentamos varrer o texto cru
        # (pode ser um JSON Lines ou um arquivo corrompido/parcial).
        texto_normalizado = conteudo

    linhas = texto_normalizado.splitlines(keepends=True)
    for inicio in range(0, len(linhas), LINHAS_POR_CHUNK):
        bloco = "".join(linhas[inicio: inicio + LINHAS_POR_CHUNK])
        yield "Arquivo", bloco


def extrair_csv(caminho: Path):
    """
    CSV: lido linha a linha com o módulo csv nativo (sem carregar tudo na
    memória), agrupado em blocos de LINHAS_POR_CHUNK linhas.
    """
    try:
        with open(caminho, "r", encoding="utf-8", errors="replace", newline="") as f:
            leitor = csv.reader(f)
            buffer = []
            for linha in leitor:
                buffer.append(", ".join(linha))
                if len(buffer) >= LINHAS_POR_CHUNK:
                    yield "Arquivo", "\n".join(buffer)
                    buffer = []
            if buffer:
                yield "Arquivo", "\n".join(buffer)
    except OSError as e:
        raise ErroExtracao(f"Falha ao ler arquivo CSV: {e}") from e
    except csv.Error as e:
        raise ErroExtracao(f"Falha ao parsear CSV: {e}") from e


def extrair_docx(caminho: Path):
    """
    DOCX: parágrafos e tabelas lidos via python-docx. Agrupado como um
    único bloco lógico "Documento" (o .docx não expõe conceito de página).
    """
    try:
        import docx
    except ImportError as e:
        raise ErroExtracao("Biblioteca python-docx não instalada.") from e

    try:
        documento = docx.Document(str(caminho))
    except Exception as e:
        raise ErroExtracao(f"Falha ao abrir DOCX (arquivo corrompido?): {e}") from e

    partes = []
    for paragrafo in documento.paragraphs:
        if paragrafo.text:
            partes.append(paragrafo.text)

    for tabela in documento.tables:
        for linha in tabela.rows:
            for celula in linha.cells:
                if celula.text:
                    partes.append(celula.text)

    texto_completo = "\n".join(partes)

    # Envia em blocos para não gerar um único bloco gigante em documentos enormes.
    linhas = texto_completo.splitlines(keepends=True) or [texto_completo]
    for inicio in range(0, len(linhas), LINHAS_POR_CHUNK):
        bloco = "".join(linhas[inicio: inicio + LINHAS_POR_CHUNK])
        if bloco.strip():
            yield "Documento", bloco


def extrair_xlsx(caminho: Path):
    """
    XLSX: usa openpyxl em modo somente leitura (read_only=True) para não
    carregar a planilha inteira na memória. Percorre aba por aba, linha por
    linha, em blocos.
    """
    try:
        import openpyxl
    except ImportError as e:
        raise ErroExtracao("Biblioteca openpyxl não instalada.") from e

    try:
        workbook = openpyxl.load_workbook(str(caminho), read_only=True, data_only=True)
    except Exception as e:
        raise ErroExtracao(f"Falha ao abrir XLSX (arquivo corrompido?): {e}") from e

    try:
        for nome_aba in workbook.sheetnames:
            aba = workbook[nome_aba]
            buffer = []
            linhas_no_buffer = 0
            for linha in aba.iter_rows(values_only=True):
                valores = [str(v) for v in linha if v is not None]
                if valores:
                    buffer.append(", ".join(valores))
                linhas_no_buffer += 1
                if linhas_no_buffer >= LINHAS_POR_CHUNK:
                    if buffer:
                        yield f"Planilha {nome_aba}", "\n".join(buffer)
                    buffer = []
                    linhas_no_buffer = 0
            if buffer:
                yield f"Planilha {nome_aba}", "\n".join(buffer)
    finally:
        workbook.close()


def extrair_xls(caminho: Path):
    """
    XLS (formato legado do Excel 97-2003): usa xlrd, que mantém suporte
    apenas a este formato nas versões atuais (openpyxl não lê .xls).
    """
    try:
        import xlrd
    except ImportError as e:
        raise ErroExtracao("Biblioteca xlrd não instalada (necessária para .xls).") from e

    try:
        workbook = xlrd.open_workbook(str(caminho))
    except Exception as e:
        raise ErroExtracao(f"Falha ao abrir XLS (arquivo corrompido?): {e}") from e

    for aba in workbook.sheets():
        buffer = []
        for indice_linha in range(aba.nrows):
            valores = [str(v) for v in aba.row_values(indice_linha) if v not in (None, "")]
            if valores:
                buffer.append(", ".join(valores))
            if len(buffer) >= LINHAS_POR_CHUNK:
                yield f"Planilha {aba.name}", "\n".join(buffer)
                buffer = []
        if buffer:
            yield f"Planilha {aba.name}", "\n".join(buffer)


def extrair_pdf(caminho: Path, ocr: bool = False):
    """
    PDF: extrai texto nativo com pypdf, página a página. Se uma página não
    possuir texto extraível e `ocr=True`, renderiza a página como imagem
    (via PyMuPDF) e roda OCR com pytesseract (idioma português).
    """
    try:
        import pypdf
    except ImportError as e:
        raise ErroExtracao("Biblioteca pypdf não instalada.") from e

    try:
        leitor = pypdf.PdfReader(str(caminho))
    except Exception as e:
        raise ErroExtracao(f"Falha ao abrir PDF (arquivo corrompido/protegido?): {e}") from e

    if leitor.is_encrypted:
        try:
            leitor.decrypt("")
        except Exception:
            raise ErroExtracao("PDF protegido por senha; não foi possível decodificar.")

    documento_fitz = None
    if ocr:
        try:
            import fitz  # PyMuPDF
            documento_fitz = fitz.open(str(caminho))
        except ImportError as e:
            raise ErroExtracao("Biblioteca PyMuPDF (fitz) não instalada para OCR.") from e
        except Exception as e:
            raise ErroExtracao(f"Falha ao abrir PDF com PyMuPDF para OCR: {e}") from e

    try:
        for indice_pagina, pagina in enumerate(leitor.pages, start=1):
            try:
                texto = pagina.extract_text() or ""
            except Exception:
                logger.warning("Falha ao extrair texto nativo da página %d de %s", indice_pagina, caminho)
                texto = ""

            if not texto.strip() and ocr and documento_fitz is not None:
                texto = _ocr_pagina_pdf(documento_fitz, indice_pagina - 1)

            if texto.strip():
                yield f"Pagina {indice_pagina}", texto
    finally:
        if documento_fitz is not None:
            documento_fitz.close()


def _ocr_pagina_pdf(documento_fitz, indice_pagina_zero_based: int) -> str:
    """Renderiza uma página do PDF como imagem e executa OCR com Tesseract (idioma pt)."""
    try:
        import fitz  # PyMuPDF
        import pytesseract
        from PIL import Image
        import io

        pagina = documento_fitz[indice_pagina_zero_based]
        # zoom 2x melhora a precisão do OCR em textos pequenos
        matriz_zoom = fitz.Matrix(2, 2)
        pixmap = pagina.get_pixmap(matrix=matriz_zoom)
        imagem_bytes = pixmap.tobytes("png")
        imagem = Image.open(io.BytesIO(imagem_bytes))
        return pytesseract.image_to_string(imagem, lang="por")
    except Exception:
        logger.exception("Falha ao executar OCR na página %d", indice_pagina_zero_based + 1)
        return ""


# Mapeamento de extensão de arquivo -> (tipo_arquivo, função extratora)
EXTENSOES_SUPORTADAS = {
    ".pdf": ("PDF", extrair_pdf),
    ".docx": ("DOCX", extrair_docx),
    ".xlsx": ("XLSX", extrair_xlsx),
    ".xls": ("XLS", extrair_xls),
    ".csv": ("CSV", extrair_csv),
    ".txt": ("TXT", extrair_txt),
    ".json": ("JSON", extrair_json),
    ".log": ("LOG", extrair_txt),
}
