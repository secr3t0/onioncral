"""Pacote do scanner de dados sensíveis baseado em Microsoft Presidio."""

__version__ = "1.0.0"
