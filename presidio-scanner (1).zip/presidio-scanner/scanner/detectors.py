"""
Configuração do motor de análise do Microsoft Presidio, incluindo os
recognizers customizados para dados brasileiros (CPF, CNPJ, telefone).

Este módulo NÃO se comunica com nenhum serviço externo: o NLP engine
(spaCy) e todos os recognizers rodam localmente.
"""

import logging
from typing import Optional

from presidio_analyzer import AnalyzerEngine, Pattern, PatternRecognizer, RecognizerRegistry
from presidio_analyzer.nlp_engine import NlpEngineProvider
from presidio_analyzer.predefined_recognizers import CreditCardRecognizer

from scanner import validators

logger = logging.getLogger("scanner.detectors")

# Nome do modelo spaCy em português utilizado pelo Presidio.
SPACY_MODEL_PT = "pt_core_news_sm"

# Entidades que o scanner efetivamente solicita ao Presidio em cada análise.
# Restringir esta lista evita processamento desnecessário (ex: PERSON, LOCATION)
# mesmo que outros recognizers estejam carregados no registry.
ENTIDADES_SUPORTADAS = [
    "CPF",
    "CNPJ",
    "RG",
    "EMAIL_ADDRESS",
    "PHONE_NUMBER_BR",
    "CREDIT_CARD",
    "IP_ADDRESS",
    "URL",
]

# Score mínimo padrão exigido para um resultado ser considerado válido.
# Evita que padrões fracos (ex: RG apenas com dígitos, sem contexto por
# perto) gerem ruído excessivo — o reforço por contexto (LemmaContextAwareEnhancer)
# soma pontos quando uma palavra-chave relevante aparece perto do match,
# permitindo que esses padrões fracos ainda sejam aceitos quando há contexto
# reforçando a detecção.
SCORE_MINIMO_PADRAO = 0.35


class CPFRecognizer(PatternRecognizer):
    """Reconhece CPF (formatado ou apenas dígitos) e valida os dígitos verificadores."""

    PATTERNS = [
        Pattern("CPF (formatado)", r"\b\d{3}\.\d{3}\.\d{3}-\d{2}\b", 0.65),
        Pattern("CPF (apenas dígitos)", r"\b\d{11}\b", 0.3),
    ]

    CONTEXT = ["cpf", "cadastro de pessoa física", "documento"]

    def __init__(self):
        super().__init__(
            supported_entity="CPF",
            supported_language="pt",
            patterns=self.PATTERNS,
            context=self.CONTEXT,
            name="CPFRecognizer",
        )

    def validate_result(self, pattern_text: str) -> Optional[bool]:
        return validators.validar_cpf(pattern_text)


class CNPJRecognizer(PatternRecognizer):
    """Reconhece CNPJ (formatado ou apenas dígitos) e valida os dígitos verificadores."""

    PATTERNS = [
        Pattern("CNPJ (formatado)", r"\b\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}\b", 0.65),
        Pattern("CNPJ (apenas dígitos)", r"\b\d{14}\b", 0.3),
    ]

    CONTEXT = ["cnpj", "cadastro nacional de pessoa jurídica", "empresa", "razão social"]

    def __init__(self):
        super().__init__(
            supported_entity="CNPJ",
            supported_language="pt",
            patterns=self.PATTERNS,
            context=self.CONTEXT,
            name="CNPJRecognizer",
        )

    def validate_result(self, pattern_text: str) -> Optional[bool]:
        return validators.validar_cnpj(pattern_text)


class TelefoneBRRecognizer(PatternRecognizer):
    """
    Reconhece números de telefone brasileiros em formatos comuns:
    (11) 91234-5678, (11) 1234-5678, 11 91234-5678, 11991234567, +55 11 91234-5678.

    Não há dígito verificador em telefones, então a validação aqui é apenas
    estrutural (via regex + reforço por palavras de contexto).
    """

    PATTERNS = [
        Pattern(
            "Telefone BR (com DDD entre parênteses)",
            r"\(\d{2}\)\s?9?\d{4}[-.\s]?\d{4}",
            0.55,
        ),
        Pattern(
            "Telefone BR (com código do país)",
            r"\+55\s?\d{2}\s?9?\d{4}[-.\s]?\d{4}",
            0.6,
        ),
        Pattern(
            "Telefone BR (sem parênteses)",
            r"\b\d{2}\s?9\d{3,4}[-.\s]?\d{4}\b",
            0.4,
        ),
    ]

    CONTEXT = ["telefone", "celular", "fone", "contato", "whatsapp", "tel"]

    def __init__(self):
        super().__init__(
            supported_entity="PHONE_NUMBER_BR",
            supported_language="pt",
            patterns=self.PATTERNS,
            context=self.CONTEXT,
            name="TelefoneBRRecognizer",
        )


class RGRecognizer(PatternRecognizer):
    """
    Reconhece números de RG (Registro Geral / carteira de identidade)
    brasileiros.

    Diferente do CPF/CNPJ, o RG é emitido por cada Secretaria de Segurança
    Pública estadual, sem um algoritmo nacional único de dígito verificador
    (o formato e a quantidade de dígitos variam por estado). Por isso, a
    validação aqui é apenas estrutural (via regex) reforçada por palavras de
    contexto, e não por checksum — o mesmo princípio usado para telefone.
    """

    PATTERNS = [
        Pattern(
            "RG (formatado com pontos e traço)",
            r"\b\d{1,2}\.\d{3}\.\d{3}-[0-9XxAaBb]\b",
            0.6,
        ),
        Pattern(
            "RG (apenas dígitos, com dígito verificador opcional)",
            r"\b\d{7,9}[0-9Xx]?\b",
            0.2,
        ),
    ]

    CONTEXT = [
        "rg",
        "registro geral",
        "identidade",
        "carteira de identidade",
        "cédula de identidade",
        "ssp",
        "órgão emissor",
    ]

    def __init__(self):
        super().__init__(
            supported_entity="RG",
            supported_language="pt",
            patterns=self.PATTERNS,
            context=self.CONTEXT,
            name="RGRecognizer",
        )


def build_analyzer() -> AnalyzerEngine:
    """
    Constrói e retorna um AnalyzerEngine do Presidio configurado para
    português, com os recognizers nativos relevantes (email, URL, IP,
    cartão de crédito) mais os recognizers customizados brasileiros
    (CPF, CNPJ, telefone).

    Esta função deve ser chamada uma vez por processo (worker), pois o
    AnalyzerEngine/spaCy não é serializável entre processos.
    """
    configuracao_nlp = {
        "nlp_engine_name": "spacy",
        "models": [{"lang_code": "pt", "model_name": SPACY_MODEL_PT}],
    }

    provider = NlpEngineProvider(nlp_configuration=configuracao_nlp)
    nlp_engine = provider.create_engine()

    registry = RecognizerRegistry(supported_languages=["pt"])
    # Carrega os recognizers nativos do Presidio (email, URL, IP, etc.) já
    # instanciados para o idioma "pt".
    registry.load_predefined_recognizers(languages=["pt"], nlp_engine=nlp_engine)

    # O CreditCardRecognizer nativo do Presidio é registrado, por padrão,
    # apenas para o idioma "en" (não faz parte do conjunto de recognizers
    # carregado automaticamente para outros idiomas via load_predefined_recognizers).
    # Como o formato de cartão de crédito (e a validação de Luhn) é
    # universal, instanciamos explicitamente para "pt".
    registry.add_recognizer(CreditCardRecognizer(supported_language="pt"))

    registry.add_recognizer(CPFRecognizer())
    registry.add_recognizer(CNPJRecognizer())
    registry.add_recognizer(TelefoneBRRecognizer())
    registry.add_recognizer(RGRecognizer())

    analyzer = AnalyzerEngine(
        nlp_engine=nlp_engine,
        registry=registry,
        supported_languages=["pt"],
    )

    logger.info("AnalyzerEngine do Presidio inicializado (idioma: pt).")
    return analyzer


def analisar_texto(analyzer: AnalyzerEngine, texto: str):
    """
    Executa a análise de um bloco de texto e retorna a lista de
    RecognizerResult do Presidio, restrita às entidades suportadas.

    Textos vazios ou apenas com espaços em branco são ignorados (evita
    chamadas desnecessárias ao pipeline de NLP).
    """
    if not texto or not texto.strip():
        return []

    try:
        resultados = analyzer.analyze(
            text=texto,
            language="pt",
            entities=ENTIDADES_SUPORTADAS,
            score_threshold=SCORE_MINIMO_PADRAO,
        )
        return _remover_sobreposicoes(resultados)
    except Exception:
        logger.exception("Falha ao analisar bloco de texto com o Presidio.")
        return []


def _remover_sobreposicoes(resultados):
    """
    Remove resultados cujo span esteja totalmente contido no span de outro
    resultado com score maior. Isso evita contagem duplicada em casos comuns
    como o UrlRecognizer nativo do Presidio capturando fragmentos de um
    endereço de e-mail já detectado como EMAIL_ADDRESS (ex: o domínio de um
    e-mail sendo também reconhecido como URL).
    """
    ordenados = sorted(resultados, key=lambda r: (r.end - r.start), reverse=True)
    mantidos = []
    for candidato in ordenados:
        contido_em_outro = False
        for mantido in mantidos:
            if (
                candidato.start >= mantido.start
                and candidato.end <= mantido.end
                and (candidato.start, candidato.end) != (mantido.start, mantido.end)
                and candidato.score <= mantido.score
            ):
                contido_em_outro = True
                break
        if not contido_em_outro:
            mantidos.append(candidato)
    # Reordena pela posição original no texto (facilita leitura/debug)
    mantidos.sort(key=lambda r: r.start)
    return mantidos
