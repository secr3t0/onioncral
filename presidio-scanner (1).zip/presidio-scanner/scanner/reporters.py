"""
Agregação dos resultados de detecção e geração dos relatórios finais:
    - resultado.csv            (sempre gerado; contagens, sem valores sensíveis)
    - resultado_detalhado.csv  (opcional, com --detailed; valores mascarados)
    - erros.csv                (arquivos que falharam durante o processamento)

Este módulo nunca grava o valor original e completo de um dado sensível em
disco — apenas versões mascaradas, mesmo no modo --detailed.
"""

import csv
import re
import threading
from collections import defaultdict
from pathlib import Path

from scanner import validators


# ---------------------------------------------------------------------------
# Mascaramento de valores por tipo de dado
# ---------------------------------------------------------------------------

def mascarar_cpf(valor: str) -> str:
    digitos = validators.somente_digitos(valor)
    if len(digitos) != 11:
        return "***"
    return f"{digitos[0:3]}.***.***-{digitos[9:11]}"


def mascarar_cnpj(valor: str) -> str:
    digitos = validators.somente_digitos(valor)
    if len(digitos) != 14:
        return "***"
    filial = digitos[8:12]
    return f"{digitos[0:2]}.***.***/{filial}-**"


def mascarar_email(valor: str) -> str:
    if "@" not in valor:
        return "***"
    usuario, dominio = valor.split("@", 1)
    if len(usuario) <= 2:
        usuario_mascarado = usuario[:1] + "*"
    else:
        usuario_mascarado = usuario[:2] + "***"
    return f"{usuario_mascarado}@{dominio}"


def mascarar_telefone(valor: str) -> str:
    digitos = validators.somente_digitos(valor)
    if len(digitos) < 8:
        return "***"

    ddd = digitos[:2] if len(digitos) >= 10 else ""
    ultimos4 = digitos[-4:]
    primeiro_do_numero = digitos[2] if len(digitos) >= 10 else digitos[0]

    if ddd:
        return f"({ddd}) {primeiro_do_numero}****-{ultimos4}"
    return f"{primeiro_do_numero}****-{ultimos4}"


def mascarar_rg(valor: str) -> str:
    limpo = re.sub(r"[^0-9A-Za-z]", "", valor)
    if len(limpo) < 4:
        return "***"
    # Mantém os 2 primeiros e o último caractere (frequentemente o dígito
    # verificador estadual), mascarando o miolo com asteriscos proporcionais
    # ao tamanho real (o RG não tem uma máscara fixa nacional como o CPF).
    miolo = "*" * (len(limpo) - 3)
    return f"{limpo[:2]}{miolo}{limpo[-1]}"


def mascarar_cartao(valor: str) -> str:
    digitos = validators.somente_digitos(valor)
    if len(digitos) < 4:
        return "***"
    ultimos4 = digitos[-4:]
    return f"**** **** **** {ultimos4}"


def mascarar_ip(valor: str) -> str:
    partes = valor.split(".")
    if len(partes) == 4:
        return f"{partes[0]}.{partes[1]}.*.*"
    return "***"


def mascarar_url(valor: str) -> str:
    m = re.match(r"^(https?://[^/]+)(/.*)?$", valor)
    if m:
        base = m.group(1)
        resto = m.group(2)
        return f"{base}/***" if resto else base
    return valor[:12] + "***" if len(valor) > 12 else "***"


def mascarar_generico(valor: str) -> str:
    if len(valor) <= 4:
        return "***"
    return valor[:2] + "***" + valor[-2:]


_MASCARADORES = {
    "CPF": mascarar_cpf,
    "CNPJ": mascarar_cnpj,
    "RG": mascarar_rg,
    "EMAIL_ADDRESS": mascarar_email,
    "PHONE_NUMBER_BR": mascarar_telefone,
    "CREDIT_CARD": mascarar_cartao,
    "IP_ADDRESS": mascarar_ip,
    "URL": mascarar_url,
}


def mascarar_valor(tipo_dado: str, valor: str) -> str:
    """Aplica o mascaramento apropriado ao tipo de dado informado."""
    funcao = _MASCARADORES.get(tipo_dado, mascarar_generico)
    try:
        return funcao(valor)
    except Exception:
        return "***"


# ---------------------------------------------------------------------------
# Agregador de resultados (thread-safe: os resultados chegam de vários workers
# via fila/futures no processo principal, mas o acesso pode ser concorrente
# se o main também estiver consumindo em threads de callback)
# ---------------------------------------------------------------------------

class AgregadorResultados:
    """
    Acumula contagens de ocorrências por (arquivo, tipo_arquivo, localizacao,
    tipo_dado) para o resultado.csv, e opcionalmente cada ocorrência
    individual (mascarada) para o resultado_detalhado.csv.
    """

    def __init__(self, detalhado: bool = False):
        self._contagens = defaultdict(int)
        self._detalhes = [] if detalhado else None
        self._detalhado = detalhado
        self._lock = threading.Lock()
        self.total_ocorrencias_por_tipo = defaultdict(int)

    def adicionar_ocorrencia(self, arquivo, tipo_arquivo, tipo_documento, localizacao, tipo_dado, valor=None, score=None):
        with self._lock:
            chave = (arquivo, tipo_arquivo, tipo_documento, localizacao, tipo_dado)
            self._contagens[chave] += 1
            self.total_ocorrencias_por_tipo[tipo_dado] += 1

            if self._detalhado:
                valor_mascarado = mascarar_valor(tipo_dado, valor) if valor is not None else ""
                self._detalhes.append(
                    (arquivo, tipo_arquivo, tipo_documento, localizacao, tipo_dado, valor_mascarado, round(score, 2) if score is not None else "")
                )

    def escrever_resultado(self, caminho_saida: Path):
        with open(caminho_saida, "w", newline="", encoding="utf-8") as f:
            escritor = csv.writer(f)
            escritor.writerow(["arquivo", "tipo_arquivo", "tipo_documento", "localizacao", "tipo_dado", "quantidade"])
            for (arquivo, tipo_arquivo, tipo_documento, localizacao, tipo_dado), quantidade in sorted(self._contagens.items()):
                escritor.writerow([arquivo, tipo_arquivo, tipo_documento, localizacao, tipo_dado, quantidade])

    def escrever_detalhado(self, caminho_saida: Path):
        if not self._detalhado:
            return
        with open(caminho_saida, "w", newline="", encoding="utf-8") as f:
            escritor = csv.writer(f)
            escritor.writerow(["arquivo", "tipo_arquivo", "tipo_documento", "localizacao", "tipo_dado", "valor_mascarado", "score"])
            for linha in self._detalhes:
                escritor.writerow(linha)


def escrever_erros(caminho_saida: Path, erros: list):
    """Grava o erros.csv com (arquivo, tipo_arquivo, tipo_documento, erro)."""
    with open(caminho_saida, "w", newline="", encoding="utf-8") as f:
        escritor = csv.writer(f)
        escritor.writerow(["arquivo", "tipo_arquivo", "tipo_documento", "erro"])
        for arquivo, tipo_arquivo, tipo_documento, erro in erros:
            escritor.writerow([arquivo, tipo_arquivo, tipo_documento, erro])
