"""
Validadores de dígitos verificadores para documentos brasileiros (CPF/CNPJ)
e utilitário de validação Luhn (usado como referência para cartões de crédito,
embora o próprio Presidio já valide Luhn internamente no CreditCardRecognizer).

Todas as funções recebem strings e trabalham apenas com os dígitos numéricos,
ignorando pontuação (pontos, traços, barras, espaços).
"""

import re

__all__ = ["somente_digitos", "validar_cpf", "validar_cnpj", "validar_luhn"]


def somente_digitos(valor: str) -> str:
    """Remove qualquer caractere que não seja dígito numérico."""
    return re.sub(r"\D", "", valor or "")


def _cpf_digito_verificador(digitos: str, peso_inicial: int) -> int:
    soma = 0
    peso = peso_inicial
    for char in digitos:
        soma += int(char) * peso
        peso -= 1
    resto = soma % 11
    return 0 if resto < 2 else 11 - resto


def validar_cpf(valor: str) -> bool:
    """
    Valida um CPF (Cadastro de Pessoa Física) conferindo os dois dígitos
    verificadores segundo o algoritmo oficial da Receita Federal.

    Retorna False para:
    - Strings com quantidade de dígitos diferente de 11.
    - Sequências de dígitos repetidos (ex: 111.111.111-11), que são
      matematicamente "válidas" no algoritmo mas nunca são CPFs reais emitidos.
    - Dígitos verificadores incorretos.
    """
    cpf = somente_digitos(valor)

    if len(cpf) != 11:
        return False

    # Sequências repetidas (000.000.000-00, 111.111.111-11, ..., 999.999.999-99)
    if cpf == cpf[0] * 11:
        return False

    dv1 = _cpf_digito_verificador(cpf[:9], 10)
    if dv1 != int(cpf[9]):
        return False

    dv2 = _cpf_digito_verificador(cpf[:10], 11)
    if dv2 != int(cpf[10]):
        return False

    return True


def _cnpj_digito_verificador(digitos: str, pesos: list) -> int:
    soma = sum(int(d) * p for d, p in zip(digitos, pesos))
    resto = soma % 11
    return 0 if resto < 2 else 11 - resto


def validar_cnpj(valor: str) -> bool:
    """
    Valida um CNPJ (Cadastro Nacional de Pessoa Jurídica) conferindo os dois
    dígitos verificadores segundo o algoritmo oficial da Receita Federal.

    Suporta apenas o formato numérico tradicional de 14 dígitos (o CNPJ
    alfanumérico introduzido pela Receita Federal a partir de 2026 não é
    contemplado por este validador).
    """
    cnpj = somente_digitos(valor)

    if len(cnpj) != 14:
        return False

    if cnpj == cnpj[0] * 14:
        return False

    pesos1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    dv1 = _cnpj_digito_verificador(cnpj[:12], pesos1)
    if dv1 != int(cnpj[12]):
        return False

    pesos2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    dv2 = _cnpj_digito_verificador(cnpj[:13], pesos2)
    if dv2 != int(cnpj[13]):
        return False

    return True


def validar_luhn(valor: str) -> bool:
    """
    Validação do algoritmo de Luhn, usada para números de cartão de crédito.
    Mantida aqui apenas como utilitário de apoio/testes; a detecção de
    cartões em si é feita pelo CreditCardRecognizer nativo do Presidio,
    que já implementa esta checagem internamente.
    """
    digitos = somente_digitos(valor)
    if len(digitos) < 12:
        return False

    soma = 0
    dobrar = False
    for char in reversed(digitos):
        d = int(char)
        if dobrar:
            d *= 2
            if d > 9:
                d -= 9
        soma += d
        dobrar = not dobrar

    return soma % 10 == 0
