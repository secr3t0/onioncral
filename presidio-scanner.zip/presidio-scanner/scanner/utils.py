"""
Utilitários gerais: configuração de logging, caminhada recursiva de
diretórios com exclusões, e a função de worker executada em cada processo
do pool (deve ser definida no nível do módulo para ser "picklable" pelo
multiprocessing).
"""

import logging
import os
from pathlib import Path

from scanner import detectors
from scanner.extractors import EXTENSOES_SUPORTADAS, ErroExtracao

# Diretórios de sistema Linux que nunca devem ser varridos por padrão.
DIRETORIOS_EXCLUIDOS_PADRAO = {
    "/proc", "/sys", "/dev", "/run", "/var/run", "/snap", "/var/lib/docker",
}

# Variável global por processo, inicializada uma única vez pelo worker.
_ANALYZER = None
_OCR_HABILITADO = False


def configurar_logging(caminho_log: Path, nivel=logging.INFO):
    """Configura logging para arquivo (scanner.log) e console simultaneamente."""
    logger_raiz = logging.getLogger()
    logger_raiz.setLevel(nivel)
    logger_raiz.handlers.clear()

    formato = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")

    handler_arquivo = logging.FileHandler(caminho_log, encoding="utf-8")
    handler_arquivo.setFormatter(formato)
    logger_raiz.addHandler(handler_arquivo)

    handler_console = logging.StreamHandler()
    handler_console.setFormatter(formato)
    handler_console.setLevel(logging.WARNING)  # console mais silencioso
    logger_raiz.addHandler(handler_console)

    return logger_raiz


def _normalizar_lista(valor: str) -> set:
    """Converte 'a,b, c' em {'a', 'b', 'c'} (vazio -> conjunto vazio)."""
    if not valor:
        return set()
    return {item.strip() for item in valor.split(",") if item.strip()}


def listar_arquivos(
    caminho_raiz: str,
    extensoes_excluidas: str = "",
    diretorios_excluidos: str = "",
):
    """
    Percorre recursivamente `caminho_raiz`, ignorando diretórios de sistema
    padrão e quaisquer exclusões definidas pelo usuário. Gera tuplas
    (caminho: Path, extensao: str) para todo arquivo encontrado (suportado
    ou não — o chamador decide o que fazer com extensões não suportadas).
    """
    exts_excluidas = {e.lower() if e.startswith(".") else f".{e.lower()}"
                      for e in _normalizar_lista(extensoes_excluidas)}
    dirs_excluidos = _normalizar_lista(diretorios_excluidos) | DIRETORIOS_EXCLUIDOS_PADRAO

    raiz = Path(caminho_raiz)
    for diretorio_atual, subdiretorios, arquivos in os.walk(raiz):
        # Remove subdiretórios excluídos da varredura (in-place, afeta o os.walk)
        subdiretorios[:] = [
            d for d in subdiretorios
            if os.path.join(diretorio_atual, d) not in dirs_excluidos
            and str(Path(diretorio_atual, d)) not in dirs_excluidos
        ]

        for nome_arquivo in arquivos:
            caminho_completo = Path(diretorio_atual) / nome_arquivo
            extensao = caminho_completo.suffix.lower()
            if extensao in exts_excluidas:
                continue
            yield caminho_completo, extensao


def inicializar_worker(ocr_habilitado: bool):
    """
    Função de inicialização de cada processo do pool: constrói o
    AnalyzerEngine do Presidio uma única vez por processo (evita reconstruir
    o pipeline de NLP a cada arquivo).
    """
    global _ANALYZER, _OCR_HABILITADO
    logging.getLogger("scanner.worker").info("Inicializando worker (pid=%s)...", os.getpid())
    _ANALYZER = detectors.build_analyzer()
    _OCR_HABILITADO = ocr_habilitado


def processar_arquivo(caminho_str: str, extensao: str):
    """
    Processa um único arquivo: extrai texto (em blocos) e roda a análise do
    Presidio em cada bloco.

    Retorna um dicionário com:
        arquivo, tipo_arquivo, ocorrencias (lista de dicts), erro (str ou None)

    Nunca levanta exceção — qualquer erro é capturado e retornado no campo
    "erro" para que o restante da varredura continue normalmente.
    """
    caminho = Path(caminho_str)
    tipo_arquivo, funcao_extratora = EXTENSOES_SUPORTADAS[extensao]

    resultado = {
        "arquivo": str(caminho),
        "tipo_arquivo": tipo_arquivo,
        "ocorrencias": [],
        "erro": None,
    }

    try:
        if funcao_extratora.__name__ == "extrair_pdf":
            gerador_blocos = funcao_extratora(caminho, ocr=_OCR_HABILITADO)
        else:
            gerador_blocos = funcao_extratora(caminho)

        for localizacao, texto in gerador_blocos:
            resultados_presidio = detectors.analisar_texto(_ANALYZER, texto)
            for r in resultados_presidio:
                valor_original = texto[r.start:r.end]
                resultado["ocorrencias"].append({
                    "localizacao": localizacao,
                    "tipo_dado": r.entity_type,
                    "valor": valor_original,
                    "score": r.score,
                })

    except ErroExtracao as e:
        resultado["erro"] = str(e)
    except Exception as e:  # noqa: BLE001 - captura ampla e intencional
        resultado["erro"] = f"Erro inesperado: {e}"

    return resultado
